<?php
 include('session.php');
    $id=$_POST['id'];
    $filename="../Admin/{$id}.zip";
    echo $filename;
	if(file_exists($filename)){
    header('Content-Disposition: attachment; filename='.basename($filename));

    //No cache
    header('Expires: 0');
    header('Cache-Control: must-revalidate');
    header('Pragma: public');

    //Define file size
    header('Content-Length: ' . filesize($filename));

    ob_clean();
    flush();
    readfile($filename);
    exit;
}
else{
	echo "File not submitted";
}
        
?>